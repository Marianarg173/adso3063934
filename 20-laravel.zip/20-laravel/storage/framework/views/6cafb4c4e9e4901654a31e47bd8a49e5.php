<?php echo e($slot); ?>

<?php /**PATH C:\Users\ramir\OneDrive\Escritorio\adso3063934\20-laravel\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>