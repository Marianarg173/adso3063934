<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Usuarios</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 30px;
        }
        table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        th {
            background: #007BFF;
            color: white;
        }
        img {
            width: 60px;
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <h2 style="text-align:center;">👥 Lista de Usuarios</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre completo</th>
                <th>Género</th>
                <th>Foto</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->fullname); ?></td>
                    <td>
                        <?php echo e($user->gender === 'Male' ? 'Masculino' : 'Femenino'); ?>

                    </td>
                    <td>
                        <?php if($user->gender === 'Male'): ?>
                            <img src="<?php echo e(asset('images/male.jpg')); ?>" alt="Hombre">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/female.png')); ?>" alt="Mujer">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($user->email); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\luisf\adso3063934\20-laravel\resources\views/users/index.blade.php ENDPATH**/ ?>