<h1>Dashboard</h1>
<h2><?php echo e(Auth::user()->fullname); ?></h2>
<h3>You're logged in!</h3>
<form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <a href="<?php echo e(route('logout')); ?>"
    onclick="event.preventDefault();
    this.closest('form').submit();">
        <?php echo e(__('Log Out')); ?>

    </a>
</form>
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\luism\OneDrive\Escritorio\adso3063934\20-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>