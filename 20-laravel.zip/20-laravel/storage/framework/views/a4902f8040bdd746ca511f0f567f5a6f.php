<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>All Pets</title>
    <style>
        table {
            border: 2px solid #aaa;
            border-collapse: collapse;
            width: 100%;
        }

        table th,
        table td {
            font-family: sans-serif;
            font-size: 10px;
            border: 2px solid #ccc;
            padding: 4px;
        }

        table tr:nth-child(odd) {
            background-color: #eee;
        }

        table th {
            background-color: #666;
            color: #fff;
            text-align: center;
        }
    </style>
</head>

<body>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Kind</th>
                <th>Weight (kg)</th>
                <th>Age</th>
                <th>Breed</th>
                <th>Location</th>
                <th>Description</th>
                <th>Photo</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pet->id); ?></td>
                <td><?php echo e($pet->name); ?></td>
                <td><?php echo e($pet->kind); ?></td>
                <td><?php echo e($pet->weight); ?></td>
                <td><?php echo e($pet->age); ?></td>
                <td><?php echo e($pet->breed); ?></td>
                <td><?php echo e($pet->location); ?></td>
                <td><?php echo e($pet->description); ?></td>
                <td>
                    <?php
                    $extension = substr($pet->image, -4);
                    ?>
                    <?php if($extension != 'webp' && $extension != '.svg'): ?>
                    <img src="<?php echo e(public_path().'/photos/'.$pet->image); ?>" width="96px">
                    <?php else: ?>
                    Webp|SVG
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html><?php /**PATH C:\Users\ramir\OneDrive\Escritorio\adso3063934\20-laravel\resources\views/pets/pdf.blade.php ENDPATH**/ ?>